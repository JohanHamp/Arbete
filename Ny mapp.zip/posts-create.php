<?php



include 'Connect.php';
include 'posts.php';
$Email = $_SESSION['Email'];
$table = "messages";


$meddelande = mysqli_real_escape_string($conn, $_POST['message']);

$sql = "INSERT INTO $table (Message, FkSenderId)
VALUES ('$meddelande', '$Email')";

if ($conn->query($sql) === TRUE) {
}
else {
  echo "error" .$sql . "<br>" . $conn->error;
}



header("Location: posts.php");
?>
