<!DOCTYPE html>
<html>
  <head>
    <title> Studentchatten </title>
    <link rel="stylesheet" href="assets/css/main.css" type="text/css" />
    <script src="js/scripts.js"></script>
  </head>
  <body>
    <div class="header">
    <h1> Välkommen till Pratbubblan! </h1>
  </div>

    <div class="frontpage regulardiv">

    <div class='loginlink'>
      <form name="loginform" method="POST" id="loginform" onsubmit="return LogInValidate()" action="login-process.php">
          <label for="username"> Email </label><br/>
          <input type="text" id="Email" name="Email"><br/>
          <label for="Password"> Password </label><br/>
          <input type="Password" id="Password" name="Password"><br/><br/>
          <input type="submit" value="Logga in" id="skicka">
      </form>
      <form name="registrationbutton" action="register.php">
          <input type="submit" value="Registrera dig!" id="registrationbutton">
      </form>
    </div>

    <div class="frontpagetext">
      Pratbubblan är en sida för er som vill prata med andra över internet. Testa och skriv med andra på sidan!
    </div>
    </div>
    </div>
    <div class="footer">
    </div>
  </body>
</html>
