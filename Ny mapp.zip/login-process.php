<?php
include 'connect.php';

$Email = mysqli_real_escape_string($conn, $_POST['Email']);
$Password = mysqli_real_escape_string($conn, $_POST['Password']);









$sql = "SELECT * FROM user WHERE Email = '$Email'";
$resultat = mysqli_query($conn, $sql)or die("Bad SQL: $sql");

while($rows=mysqli_fetch_assoc($resultat))
    {
        $DbEmail = $rows['Email'];
        $DbPass = $rows['Password'];
        $DbSalt = $rows['salt'];
    }

$TempPassword =md5($Password .= $DbSalt);

if ($TempPassword == $DbPass) {
  echo "Success";
  SESSION_START();
  $_SESSION['loggedin'] = true;
  $_SESSION['Email'] = $Email;
  header('Location: posts.php');
  exit();
}
else {
  echo "Fel inloggningsuppgifter";
}
 ?>
